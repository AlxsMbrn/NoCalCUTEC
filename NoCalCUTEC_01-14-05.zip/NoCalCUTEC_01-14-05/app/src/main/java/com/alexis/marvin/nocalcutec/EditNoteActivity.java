package com.alexis.marvin.nocalcutec;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class EditNoteActivity extends AppCompatActivity {

    private static final String NOMBRE = "";
    EditText edtNota;
    //int recibirCadena = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_note);
    }

    public void btnGuardar(View v){
        Toast t=Toast.makeText(this,"Nota guardada", Toast.LENGTH_SHORT);
        t.show();

        Intent intGuardar = new Intent(this,NoCalCUTECActivity.class);
        startActivity(intGuardar);
        finish();
    }

    public void btnCancelar(View v){
        AlertDialog.Builder dialogo1 = new AlertDialog.Builder(this);
        dialogo1.setTitle("¿Quiere cancelar la edición?");
        dialogo1.setMessage("Si cancela perderá lo editado");
        dialogo1.setCancelable(false);
        dialogo1.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo1, int id) {
                aceptar();
            }
        });
        dialogo1.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogo1, int id) {
                cancelar();
            }
        });
        dialogo1.show();
    }

    public void cancelar() {
        Toast t=Toast.makeText(this,"Sigue editando", Toast.LENGTH_SHORT);
        t.show();
    }

    public void aceptar() {
        finish();
    }

        //Intent intCancelar = new Intent(this,NoCalCUTECActivity.class);
        //startActivity(intCancelar);
        //finish();
}

