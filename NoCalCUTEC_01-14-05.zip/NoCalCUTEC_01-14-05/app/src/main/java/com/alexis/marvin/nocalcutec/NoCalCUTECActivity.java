package com.alexis.marvin.nocalcutec;

import android.content.Intent;
import android.provider.SyncStateContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class NoCalCUTECActivity extends AppCompatActivity {
    //Invocar al tipo de variable TextView y definirla con un nombre
    TextView tvMarcoContenedor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_no_cal_cutec);
    }

    //El metodo debera contener el mismo nombre que se le asigno al metodo onClick en el xml del (buttom)
    public void btnAgregarNota(View v)
    {
        Intent intent = new Intent(this,EditNoteActivity.class);
        startActivity(intent);
    }

}
